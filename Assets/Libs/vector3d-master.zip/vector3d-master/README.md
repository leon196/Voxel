vector3d
========

Double precision Vector Libraries for Unity3D

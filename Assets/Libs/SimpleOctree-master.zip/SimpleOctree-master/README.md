SimpleOctree
============

A simple octree with good commenting for learning how octrees work. Blog post incoming with description, or read comments in Octree.h

Usage
============
make && ./octree
